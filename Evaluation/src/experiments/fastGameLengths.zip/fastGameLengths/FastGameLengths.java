package experiments.fastGameLengths;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;

import game.Game;
import gnu.trove.list.array.TIntArrayList;
import main.math.Stats;
import other.AI;
import other.GameLoader;
import other.context.Context;
import other.trial.Trial;
import search.mcts.MCTS;
import search.mcts.finalmoveselection.RobustChild;
import search.mcts.playout.HeuristicPlayout;
import search.mcts.selection.UCB1;
import search.minimax.AlphaBetaSearch;
import search.minimax.HeuristicSampling;

//-----------------------------------------------------------------------------

/**
 * Experiments to test Heuristic Sampling for fast game length estimates.
 * @author cambolbro
 */
public class FastGameLengths
{
	// Expected game lengths are from the Game Complexity wikipedia page:
	// https://en.wikipedia.org/wiki/Game_complexity
	// -1 means average game length is not know for this game.
		
	public enum GameName
	{
//		ArdRi(2, -1),           
//		Breakthrough(2, -1),    
//		Hnefatafl(2, -1),       
//		Oware(2, 60),           
//		Tablut(2, -1),          
//		Reversi(2, 58),         
//		NineMensMorris(2, 50),  
		TicTacToe(2, 9),       
		Domineering(2, 30),     
		EnglishDraughts(2, 70), 
		ConnectFour(4, 36),     
		Fanorona(2, 44),        
		GoMoku(2, 30),          
		Yavalath(2, -1), 
		Amazons(3, 84),         
		LinesOfAction(2, 44),   
		Halma(2, -1),           
		Chess(2, 70),           
		;

		//-------------------------------------

		private int depth = 0;      // search depth 
		private int expected = -1;  // expected length
		
		//-------------------------------------
		
		private GameName(final int depth, final int expected)
		{
			this.depth    = depth;
			this.expected = expected;
		}

		//-------------------------------------

		public int depth()
		{
			return depth;
		}
		
		public int expected()
		{
			return expected;
		}
	}
	
	//-------------------------------------------------------------------------
		
	void test()
	{
		//test(GameName.Amazons);
		//test(GameName.Chess);
		//test(GameName.ConnectFour);
		//test(GameName.Domineering);
		//test(GameName.EnglishDraughts);
		//test(GameName.Fanorona);
		//test(GameName.GoMoku);
		//test(GameName.Halma);
		//test(GameName.LinesOfAction);
		//test(GameName.Reversi);
		//test(GameName.TicTacToe);
		//test(GameName.Yavalath);
		
		for (final GameName gameName : GameName.values())
		{
			if (gameName.ordinal() >= 10)
				test(gameName);
		}
	}
	
	void test(final GameName gameName)
	{
		Game game = null;
		
		switch (gameName)
		{
//		case ArdRi:
//			game = GameLoader.loadGameFromName("ArdRi.lud");
//			break;
		case Amazons:
			game = GameLoader.loadGameFromName("Amazons.lud");
			break;
//		case Breakthrough:
//			game = GameLoader.loadGameFromName("Breakthrough.lud");
//			break;
		case Chess:
			game = GameLoader.loadGameFromName("Chess.lud");
			break;
		case ConnectFour:
			game = GameLoader.loadGameFromName("Connect Four.lud");
			break;
		case Domineering:
			game = GameLoader.loadGameFromName("Domineering.lud", Arrays.asList("Rows/8", "Columns/8"));
			break;
		case EnglishDraughts:
			game = GameLoader.loadGameFromName("English Draughts.lud");
			break;
		case Fanorona:
			game = GameLoader.loadGameFromName("Fanorona.lud");
			break;
		case GoMoku:
			game = GameLoader.loadGameFromName("GoMoku.lud");
			break;
		case Halma:
			//game = GameLoader.loadGameFromName("Halma.lud", Arrays.asList("Board Size/6x6"));
			game = GameLoader.loadGameFromName("Halma.lud", Arrays.asList("Board Size/6x6"));
			break;
//		case Hnefatafl:
//			game = GameLoader.loadGameFromName("Hnefatafl.lud");
//			break;
		case LinesOfAction:
			game = GameLoader.loadGameFromName("Lines of Action.lud");
			break;
//		case NineMensMorris:
//			game = GameLoader.loadGameFromName("Nine Men's Morris.lud");
//			break;
//		case Oware:
//			game = GameLoader.loadGameFromName("Oware.lud");
//			break;
//		case Reversi:
//			game = GameLoader.loadGameFromName("Reversi.lud");
//			break;
//		case Tablut:
//			game = GameLoader.loadGameFromName("Tablut.lud");
//			break;
		case TicTacToe:
			game = GameLoader.loadGameFromName("Tic-Tac-Toe.lud");
			break;
		case Yavalath:
			game = GameLoader.loadGameFromName("Yavalath.lud");
			break;
		}
		
		System.out.println("==================================================");
		System.out.println("Loaded game " + game.name() + ", " + gameName.expected() + " moves expected.");
		
//		lengthRandomParallel(game, 1000);
//				
//		//lengthAlphaBeta(gameName, game, 0);
//		//lengthAlphaBeta(gameName, game, 1);
//		//lengthAlphaBeta(gameName, game, 2);
//		//lengthAlphaBeta(gameName, game, 3);
//		//lengthAlphaBeta(gameName, game, 4);
//		//lengthAlphaBeta(gameName, game, gameName.depth());
//		
//		for (int depth = 1; depth <= gameName.depth(); depth++)
//			lengthAlphaBeta(gameName, game, depth);
//		
//		int threshold = 2; 
//		for (int hs = 0; hs < 6; hs++)
//		{
//			lengthHS(gameName, game, threshold);
//			threshold *= 2;
//		}
		
		
		//System.out.println("BF (serial) = " + branchingFactorSerial(game, 10));
		System.out.println("BF (parallel) = " + branchingFactorParallel(game, 10));

		lengthUCT(gameName, game, 1000);

		//compareUCThs(gameName, game, 1000);
	}
	
	//-------------------------------------------------------------------------

	public static int gameLength(final Trial trial, final Game game)
	{
		//return trial.numLogicalDecisions(game);
		//return trial.numMoves() - trial.numForcedPasses();
		return trial.numTurns() - trial.numForcedPasses();
	}
	
	//-------------------------------------------------------------------------

	/**
	 * @param game Single game object shared between threads.
	 */
	final static void compareUCThs(final GameName gameName, final Game game, final int iterations)
	{
		final int MaxTrials = 1000;
				
		final int numPlayers = game.players().count();
	
		final long startAt = System.nanoTime();
				
		AI aiA = null;
		AI aiB = null;
		
		System.out.println("\nUCT (" + iterations + " iterations).");
				
		// Run trials concurrently
		final List<Future<TrialRecord>> futures = new ArrayList<>(MaxTrials);
		
		final CountDownLatch latch = new CountDownLatch(MaxTrials);
			
		for (int t = 0; t < MaxTrials; t++)
		{
			final FutureTrial future = new FutureTrialIterations(latch);
			
			final int starter = t % 2;
			
			final List<AI> ais = new ArrayList<>();
			ais.add(null);  // null placeholder for player 0
			
			final String heuristicsFilePath = "src/experiments/fastGameLengths/Heuristics_" + gameName + "_Good.txt";
			try
			{				
				//aiA = new AlphaBetaSearch(heuristicsFilePath);
				aiA = MCTS.createUCT();
				
				aiB = new MCTS
					  (
						  new UCB1(),
						  new HeuristicPlayout(heuristicsFilePath),
						  new RobustChild()
					  );
				aiB.friendlyName = "UCThs";
				
				//aiB = new AlphaBetaSearch("src/experiments/fastGameLengths/Heuristics_Tablut_Current.txt");
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}  
			
			if (starter == 0)
			{
				ais.add(aiA);
				ais.add(aiB);
			}
			else
			{
				ais.add(aiB);
				ais.add(aiA);
			}
			
			futures.add(future.runTrial(game, ais, starter, iterations));	
		}
		
		try
		{
			latch.await();
		} 
		catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
		
		// Accumulate wins per player		
		final Stats stats = new Stats("UCThs Results");
		final double[] results = new double[numPlayers + 1];
		try 
		{
			for (int t = 0; t < MaxTrials; t++)
			{
				final TrialRecord trialRecord = futures.get(t).get();
				final Trial trial = trialRecord.trial();
				
				final int length = gameLength(trial, game);
				
				//System.out.print((t == 0 ? "\n" : "") + length + " ");
				
				if (length < 1000)
					stats.addSample(gameLength(trial, game));
				
				final int result = trial.status().winner();  //futures.get(t).get().intValue();
				if (result == 0)
				{
					// Draw: share win
					results[0] += 0.5;
					results[1] += 0.5;
				}
				else
				{
					// Reward winning AI
					if (trialRecord.starter() == 0)
					{
						if (result == 1)
							results[0]++;
						else
							results[1]++;
					}
					else 
					{
						if (result == 1)
							results[1]++;
						else
							results[0]++;
					}
				}
				
				//System.out.println(trialRecord.starter() + " => " + trial.status().winner());
			}
		}
		catch (final InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
			//fail();
		}
				
		//System.out.println("\naiA=" + results[0] + ", aiB=" + results[1] + ".");
		System.out.println("aiA success rate " + results[0] / MaxTrials * 100 + "%.");  //+ ", aiB=" + results[1] + ".");
	
		stats.measure();
		stats.showFull();
		
		//System.out.println("Expected length is " + (gameName.expected() == -1 ? "not known" : gameName.expected()) + ".");
		
		//executor.shutdown();
		
		final double secs = (System.nanoTime() - startAt) / 1000000000.0;
		System.out.println("UCT (" + iterations + ") " + secs + "s (" + (secs / MaxTrials) + "s per game).");
	}
	
	//-------------------------------------------------------------------------

	/**
	 * @param game Single game object shared between threads.
	 */
	final static void lengthUCT(final GameName gameName, final Game game, final int iterations)
	{
		final int MaxTrials = 100;  //10;
				
		final int numPlayers = game.players().count();
	
		final long startAt = System.nanoTime();
				
		AI aiA = null;
		AI aiB = null;
		
		System.out.println("\nUCT (" + iterations + " iterations).");
				
		// Run trials concurrently
		final List<Future<TrialRecord>> futures = new ArrayList<>(MaxTrials);
		
		final CountDownLatch latch = new CountDownLatch(MaxTrials);
			
		for (int t = 0; t < MaxTrials; t++)
		{
			final int starter = t % 2;
			
			final FutureTrial future = new FutureTrialIterations(latch);
			
			final List<AI> ais = new ArrayList<>();
			ais.add(null);  // null placeholder for player 0
			
			//final String heuristicsFilePath = "src/experiments/fastGameLengths/Heuristics_" + gameName + "_Good.txt";
			try
			{
				aiA = MCTS.createUCT();
				aiB = MCTS.createUCT();
				
				//aiB = new AlphaBetaSearch("src/experiments/fastGameLengths/Heuristics_Tablut_Current.txt");
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}  
			
			if (starter == 0)
			{
				ais.add(aiA);
				ais.add(aiB);
			}
			else
			{
				ais.add(aiB);
				ais.add(aiA);
			}
			
			futures.add(future.runTrial(game, ais, starter, iterations));	
		}
		
		try
		{
			latch.await();
		} 
		catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
		
		// Accumulate wins per player		
		final Stats stats = new Stats("HS Results");
		final double[] results = new double[numPlayers + 1];
		try 
		{
			for (int t = 0; t < MaxTrials; t++)
			{
				final TrialRecord trialRecord = futures.get(t).get();
				final Trial trial = trialRecord.trial();
				
				final int length = gameLength(trial, game);
				
				//System.out.print((t == 0 ? "\n" : "") + length + " ");
				
				if (length < 1000)
					stats.addSample(gameLength(trial, game));
				
				final int result = trial.status().winner();  //futures.get(t).get().intValue();
				if (result == 0)
				{
					// Draw: share win
					results[0] += 0.5;
					results[1] += 0.5;
				}
				else
				{
					// Reward winning AI
					if (trialRecord.starter() == 0)
					{
						if (result == 1)
							results[0]++;
						else
							results[1]++;
					}
					else 
					{
						if (result == 1)
							results[1]++;
						else
							results[0]++;
					}
				}
				
				//System.out.println(trialRecord.starter() + " => " + trial.status().winner());
			}
		}
		catch (final InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
			//fail();
		}
				
		//System.out.println("\naiA=" + results[0] + ", aiB=" + results[1] + ".");
		System.out.println("aiA success rate " + results[0] / MaxTrials * 100 + "%.");  //+ ", aiB=" + results[1] + ".");
	
		stats.measure();
		stats.showFull();
		
		//System.out.println("Expected length is " + (gameName.expected() == -1 ? "not known" : gameName.expected()) + ".");
		
		//executor.shutdown();
		
		final double secs = (System.nanoTime() - startAt) / 1000000000.0;
		System.out.println("UCT (" + iterations + ") " + secs + "s (" + (secs / MaxTrials) + "s per game).");
	}
	
	//-------------------------------------------------------------------------

	/**
	 * @param game Single game object shared between threads.
	 */
	final static void lengthHS(final GameName gameName, final Game game, final int fraction)
	{
		final int MaxTrials = 1000;
				
		final int numPlayers = game.players().count();
	
		final long startAt = System.nanoTime();
				
		AI aiA = null;
		AI aiB = null;
		
		System.out.println("\nHS fraction 1/" + fraction + ".");
				
		// Run trials concurrently
		final List<Future<TrialRecord>> futures = new ArrayList<>(MaxTrials);
		
		final CountDownLatch latch = new CountDownLatch(MaxTrials);
			
		for (int t = 0; t < MaxTrials; t++)
		{
			//final FutureTrial future = new FutureTrialAB(executor, latch);
			final FutureTrial future = new FutureTrialDepth(latch);
			
			final int starter = t % 2;
			
			final List<AI> ais = new ArrayList<>();
			ais.add(null);  // null placeholder for player 0
			
			final String heuristicsFilePath = "src/experiments/fastGameLengths/Heuristics_" + gameName + "_Good.txt";
			try
			{
				aiA = new HeuristicSampling(heuristicsFilePath);
				aiB = new HeuristicSampling(heuristicsFilePath);
				
				((HeuristicSampling)aiA).setThreshold(fraction);
				((HeuristicSampling)aiB).setThreshold(fraction);
				
				//aiB = new AlphaBetaSearch("src/experiments/fastGameLengths/Heuristics_Tablut_Current.txt");
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}  
			
			if (t % 2 == 0)
			{
				ais.add(aiA);
				ais.add(aiB);
			}
			else
			{
				ais.add(aiB);
				ais.add(aiA);
			}
			
			futures.add(future.runTrial(game, ais, starter, 1));	
		}
		
		try
		{
			latch.await();
		} 
		catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
		
		// Accumulate wins per player		
		final Stats stats = new Stats("HS Results");
		final double[] results = new double[numPlayers + 1];
		try 
		{
			for (int t = 0; t < MaxTrials; t++)
			{
				final TrialRecord trialRecord = futures.get(t).get();
				final Trial trial = trialRecord.trial();
				
				final int length = gameLength(trial, game);
				
				//System.out.print((t == 0 ? "\n" : "") + length + " ");
				
				if (length < 1000)
					stats.addSample(gameLength(trial, game));
				
				final int result = trial.status().winner();  //futures.get(t).get().intValue();
				if (result == 0)
				{
					// Draw: share win
					results[0] += 0.5;
					results[1] += 0.5;
				}
				else
				{
					// Reward winning AI
					if (trialRecord.starter() == 0)
					{
						if (result == 1)
							results[0]++;
						else
							results[1]++;
					}
					else 
					{
						if (result == 1)
							results[1]++;
						else
							results[0]++;
					}
				}
			}
		}
		catch (final InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
			//fail();
		}
				
		//System.out.println("\naiA=" + results[0] + ", aiB=" + results[1] + ".");
		System.out.println("aiA success rate " + results[0] / MaxTrials * 100 + "%.");  //+ ", aiB=" + results[1] + ".");
	
		stats.measure();
		stats.showFull();
		
		//System.out.println("Expected length is " + (gameName.expected() == -1 ? "not known" : gameName.expected()) + ".");
		
		//executor.shutdown();
		
		final double secs = (System.nanoTime() - startAt) / 1000000000.0;
		System.out.println("Heuristic Sampling (1/" + fraction + ") " + secs + "s (" + (secs / MaxTrials) + "s per game).");
	}
		
	//-------------------------------------------------------------------------
	
	/**
	 * @param game Single game object shared between threads.
	 */
	final static void lengthAlphaBeta(final GameName gameName, final Game game, final int depth)
	{
		final int MaxTrials = 1000;
		
		final int numPlayers = game.players().count();
	
		final long startAt = System.nanoTime();
				
		AI aiA = null;
		AI aiB = null;
		
		System.out.println("\nAB depth " + depth + ".");
		
		//final ExecutorService executor = Executors.newFixedThreadPool(10);  //MaxTrials);  //10);
		
//		try
//		{
//			aiA = new AlphaBetaSearch(HeuristicsFilePaths[0][0]);
//			aiB = new AlphaBetaSearch(HeuristicsFilePaths[0][1]);
//		} 
//		catch (Exception e)
//		{
//			e.printStackTrace();
//		}  		
//			
//		aiA.initAI(game, 1);
//		aiB.initAI(game, 2);
//
//		final Heuristics heuristicsA = ((AlphaBetaSearch)aiA).heuristics();
//		final Heuristics heuristicsB = ((AlphaBetaSearch)aiB).heuristics();
//		
//		System.out.println("heuristicsA: " + (heuristicsA == null ? "null" : heuristicsA.toString()));
//		System.out.println("heuristicsB: " + (heuristicsB == null ? "null" : heuristicsB.toString()));
		
		// Run trials concurrently
		final List<Future<TrialRecord>> futures = new ArrayList<>(MaxTrials);
		
		final CountDownLatch latch = new CountDownLatch(MaxTrials);
			
		for (int t = 0; t < MaxTrials; t++)
		{
			//final FutureTrial future = new FutureTrialAB(executor, latch);
			final FutureTrial future = new FutureTrialDepth(latch);
			
			final int starter = t % 2;
			
			final List<AI> ais = new ArrayList<>();
			ais.add(null);  // null placeholder for player 0
			
			final String heuristicsFilePath = "src/experiments/fastGameLengths/Heuristics_" + gameName + "_Good.txt";
			try
			{
				aiA = new AlphaBetaSearch(heuristicsFilePath);
				aiB = new AlphaBetaSearch(heuristicsFilePath);
				//aiB = new AlphaBetaSearch("src/experiments/fastGameLengths/Heuristics_Tablut_Current.txt");
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}  
			
			if (t % 2 == 0)
			{
				ais.add(aiA);
				ais.add(aiB);
			}
			else
			{
				ais.add(aiB);
				ais.add(aiA);
			}
			
			futures.add(future.runTrial(game, ais, starter, depth));	
		}
		
		try
		{
			latch.await();
		} 
		catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
		
		// Accumulate wins per player		
		final Stats stats = new Stats("AI Results");
		final double[] results = new double[numPlayers + 1];
		try 
		{
			for (int t = 0; t < MaxTrials; t++)
			{
				final TrialRecord trialRecord = futures.get(t).get();
				final Trial trial = trialRecord.trial();
				
				final int length = gameLength(trial, game);
				
				//System.out.print((t == 0 ? "\n" : "") + length + " ");
				
				if (length < 1000)
					stats.addSample(gameLength(trial, game));
				
				final int result = trial.status().winner();
				if (result == 0)
				{
					// Draw: share win
					results[0] += 0.5;
					results[1] += 0.5;
				}
				else
				{
					// Reward winning AI
					if (trialRecord.starter() == 0)
					{
						if (result == 1)
							results[0]++;
						else
							results[1]++;
					}
					else 
					{
						if (result == 1)
							results[1]++;
						else
							results[0]++;
					}
				}
				
				//System.out.println(trialRecord.starter() + " => " + trial.status().winner());
			}
		}
		catch (final InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
			//fail();
		}
				
		//System.out.println("\naiA=" + results[0] + ", aiB=" + results[1] + ".");
		System.out.println("aiA success rate " + results[0] / MaxTrials * 100 + "%.");  //+ ", aiB=" + results[1] + ".");
	
		stats.measure();
		stats.showFull();
		
		//System.out.println("Expected length is " + (gameName.expected() == -1 ? "not known" : gameName.expected()) + ".");
		
		//executor.shutdown();
		
		final double secs = (System.nanoTime() - startAt) / 1000000000.0;
		System.out.println("Alpha-Beta (" + depth + ") in " + secs + "s (" + (secs / MaxTrials) + "s per game).");
	}
	
	//-------------------------------------------------------------------------

	double lengthRandomSerial(final Game game, final int numTrials)
	{
		final long startAt = System.nanoTime();
		
		final Trial refTrial = new Trial(game);
		final Context context = new Context(game, refTrial);
		
		final Stats stats = new Stats("Serial Random");
		
		//int totalLength = 0;
		for (int t = 0; t < numTrials; t++)
		{
			game.start(context);
			final Trial trial = game.playout(context, null, 1.0, null, -1, -1, ThreadLocalRandom.current());
			//totalLength += trial.numLogicalDecisions(game);
			stats.addSample(gameLength(trial, game));
		}
		stats.measure();
		
		final double secs = (System.nanoTime() - startAt) / 1000000000.0;

		stats.showFull();
		System.out.println("Serial in " + secs + "s.");
		
		return stats.mean();
	}

	double lengthRandomParallel(final Game game, final int numTrials)
	{
		final long startAt = System.nanoTime();

		final ExecutorService executorService = Executors.newFixedThreadPool(numTrials);
		final List<Future<Context>> playedContexts = new ArrayList<Future<Context>>(numTrials);
	
		final CountDownLatch latch = new CountDownLatch(numTrials);
		
		for (int t = 0; t < numTrials; t++)
		{
			final Trial trial = new Trial(game);
			final Context context = new Context(game, trial);
			//trial.storeLegalMovesHistorySizes();
			
			playedContexts.add
			(
				executorService.submit
				(
					() -> 
					{
						game.start(context);
						game.playout(context, null, 1.0, null, -1, -1, ThreadLocalRandom.current());
						latch.countDown();
						return context;
					}
				)
			);
		}
			
		try
		{
			latch.await();
		} 
		catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}
		
		// Accumulate lengths over all trials
		final Stats stats = new Stats("Parallel Random");

		//double totalLength = 0;
		try 
		{
			for (int t = 0; t < numTrials; t++)
			{
				final Context context = playedContexts.get(t).get();
				stats.addSample(gameLength(context.trial(), game));
			}
		}
		catch (final InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
			//fail();
		}
		stats.measure();
		
		final double secs = (System.nanoTime() - startAt) / 1000000000.0;
		
		stats.showFull();
		System.out.println("Random concurrent in " + secs + "s (" + (secs / numTrials) +"s per game).");
		
		executorService.shutdown();
		
		return stats.mean();
	}
	
	//-------------------------------------------------------------------------

//	double branchingFactorSerial(final Game game, final int numTrials)
//	{
//		final long startAt = System.nanoTime();
//		
//		final Trial trial = new Trial(game);
//		final Context context = new Context(game, trial);
//		
//		int totalDecisions = 0;
//		
//		for (int t = 0; t < numTrials; t++)
//		{
//			game.start(context);
//			final Trial endTrial = game.playout(context, null, 1.0, null, -1, -1, ThreadLocalRandom.current());
//			final int numDecisions = endTrial.numMoves() - endTrial.numInitialPlacementMoves();
//			totalDecisions += numDecisions;
//		}
//		
//		final double secs = (System.nanoTime() - startAt) / 1000000000.0;
//		System.out.println("BF serial in " + secs + "s.");
//		
//		return totalDecisions / (double)numTrials;
//	}

	double branchingFactorParallel(final Game game, final int numTrials)
	{
		//final long startAt = System.nanoTime();

		// Disable custom playouts that cannot properly store history of legal moves per state
		game.disableMemorylessPlayouts();
						
		final ExecutorService executor = Executors.newFixedThreadPool(numTrials);
		final List<Future<Trial>> futures = new ArrayList<Future<Trial>>(numTrials);
	
		final CountDownLatch latch = new CountDownLatch(numTrials);

		for (int t = 0; t < numTrials; t++)
		{
			final Trial trial = new Trial(game);
			final Context context = new Context(game, trial);
			trial.storeLegalMovesHistorySizes();
			
			futures.add
			(
				executor.submit
				(
					() -> 
					{
						game.start(context);
						game.playout(context, null, 1.0, null, -1, -1, ThreadLocalRandom.current());
						latch.countDown();
						return trial;
					}
				)
			);
		}
			
		try
		{
			latch.await();
		} 
		catch (InterruptedException e1)
		{
			e1.printStackTrace();
		}

		// Accumulate total BFs over all trials
		double totalBF = 0;
		try 
		{
			for (int t = 0; t < numTrials; t++)
			{
				final Trial trial = futures.get(t).get();

				//final Trial trial = playedContexts.get(t).get();
				final TIntArrayList branchingFactors = trial.auxilTrialData().legalMovesHistorySizes();
				
				double bfAcc = 0;
				if (branchingFactors.size() > 0)
				{
					for (int m = 0; m < branchingFactors.size(); m++)
						bfAcc += branchingFactors.getQuick(m);
					bfAcc /= branchingFactors.size();
				}
				totalBF += bfAcc;
			}
		}
		catch (final InterruptedException | ExecutionException e)
		{
			e.printStackTrace();
		}
		
		//final double secs = (System.nanoTime() - startAt) / 1000000000.0;
		//System.out.println("secs=" + secs);
		
		executor.shutdown();
		
		return totalBF / numTrials;

	}	
	
	//-------------------------------------------------------------------------
	
	public static void main(String[] args)
	{
		final FastGameLengths sd = new FastGameLengths();
		sd.test();
	}

	//-------------------------------------------------------------------------

}
