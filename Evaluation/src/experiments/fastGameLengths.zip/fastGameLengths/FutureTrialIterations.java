package experiments.fastGameLengths;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import game.Game;
import other.AI;
import other.context.Context;
import other.model.Model;
import other.trial.Trial;
import main.Status;

//-----------------------------------------------------------------------------

/**
 * Thread for running HS version of trial. 
 * @author cambolbro
 */
public class FutureTrialIterations implements FutureTrial
{       
    //private ExecutorService executor;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    
    final CountDownLatch latch;
    
    //public FutureTrialAB(final ExecutorService executor, final CountDownLatch latch)
    public FutureTrialIterations(final CountDownLatch latch)
    {
     	this.latch = latch;
    	//this.executor = executor;
    }
    
    /**
     * @param game  The single game object, shared across threads. 
     * @param ais   AI to use for each player.
     * @param depth Search depth.  
     */
    @Override
    public Future<TrialRecord> runTrial
    (
    	final Game game, final List<AI> ais, final int starter, final int iterations
    ) 
    {
        return executor.submit(() -> 
        {
        	//System.out.println("Submitted id=" + id + ", lower=" + lower + ", upper=" + upper + ".");
        	
        	//final int numPlayers = game.players().count();
        	//System.out.println("numPlayers=" + numPlayers);
        	
        	final Trial trial = new Trial(game);
			final Context context = new Context(game, trial);
				
//			game.start(context);
//			
//			// Set up AIs
//			for (int pid = 1; pid < numPlayers + 1; pid++)
//				ais.get(pid).initAI(game, pid);
//
//			while (!context.trial().over())
//			{
//				final int mover = context.state().mover();
//				
//				if (mover < 1 || mover > numPlayers)
//					System.out.println("** Bad mover index: " + mover);
//				
//				final Move move = ais.get(mover).selectAction
//				(
//					game, new Context(context), -1, -1, depth
//				);
//				game.apply(context, move);
//					
//				//if (trial.numberOfTurns() % 10 == 0)
//				//	System.out.print(".");
//			}
//			//System.out.println(trialId + ": " + context.trial().status() + " (P" + pidHigher + " is superior).");
			
			game.start(context);

			for (int p = 1; p <= game.players().count(); ++p)
				ais.get(p).initAI(game, p);
   
//			final Heuristics heuristicsA = ((AlphaBetaSearch)ais.get(1)).heuristics();
//			final Heuristics heuristicsB = ((AlphaBetaSearch)ais.get(2)).heuristics();
//		
//			System.out.println("heuristicsA: " + (heuristicsA == null ? "null" : heuristicsA.toString()));
//			System.out.println("heuristicsB: " + (heuristicsB == null ? "null" : heuristicsB.toString()));

			final Model model = context.model();
			while (!trial.over())
				model.startNewStep(context, ais, -1, iterations, -1, 0);

			final Status status = context.trial().status();
			System.out.print(status.winner());	
			
			latch.countDown();
			
			return new TrialRecord(starter, trial);  //Integer.valueOf(status.winner());
		});
    }
}
